var searchData=
[
  ['get_5fdiags_102',['get_diags',['../class_c_s_r_matrix.html#a4e5ef73bb62e261bcee05048cb874d18',1,'CSRMatrix']]],
  ['gmres_103',['GMRES',['../namespaceutil_1_1dense.html#a438d454a28d2f4cae13030c734af7180',1,'util::dense']]]
];
