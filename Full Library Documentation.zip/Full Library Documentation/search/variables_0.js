var searchData=
[
  ['band_5fmat_138',['band_mat',['../class_banded_mat.html#adfb5c8b9a29cfd34272858c84e1fd3d0',1,'BandedMat']]]
];
