var searchData=
[
  ['values_152',['values',['../class_matrix.html#a089a93af414a79e3bd6dec66eed145b1',1,'Matrix']]]
];
