var searchData=
[
  ['spdmatrix_80',['SPDMatrix',['../class_s_p_d_matrix.html',1,'']]],
  ['symmetricmatrix_81',['SymmetricMatrix',['../class_symmetric_matrix.html',1,'']]]
];
