var searchData=
[
  ['col_5findex_139',['col_index',['../class_c_s_r_matrix.html#a9cb1ae2d245feff7ea1b9edeec80faad',1,'CSRMatrix']]],
  ['col_5fsz_140',['col_sz',['../class_banded_mat.html#a424bb054e19949b65616fc63e0a826a9',1,'BandedMat']]],
  ['cols_141',['cols',['../class_matrix.html#a28e99540a5a95cb42dfaceb8942a48bd',1,'Matrix']]]
];
