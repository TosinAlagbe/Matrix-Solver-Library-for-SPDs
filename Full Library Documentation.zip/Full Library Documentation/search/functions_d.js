var searchData=
[
  ['rotation_124',['rotation',['../namespaceutil_1_1dense.html#a2bfe2852dda4206ab8f16d207568e4bc',1,'util::dense']]]
];
