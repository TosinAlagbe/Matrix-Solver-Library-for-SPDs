var searchData=
[
  ['rotation_49',['rotation',['../namespaceutil_1_1dense.html#a2bfe2852dda4206ab8f16d207568e4bc',1,'util::dense']]],
  ['row_5fposition_50',['row_position',['../class_c_s_r_matrix.html#a957d27a1f93fdf5776ea44a9316265f1',1,'CSRMatrix']]],
  ['rows_51',['rows',['../class_matrix.html#acd67456c163fd2259c8aef072c9177fa',1,'Matrix']]]
];
