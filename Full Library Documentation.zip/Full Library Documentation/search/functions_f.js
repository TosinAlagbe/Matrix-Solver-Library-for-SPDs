var searchData=
[
  ['transpose_134',['transpose',['../class_c_s_r_matrix.html#a1ae7ab83935fb28db618db0ccab9a1f1',1,'CSRMatrix']]]
];
