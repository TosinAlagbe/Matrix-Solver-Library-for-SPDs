var searchData=
[
  ['jacobi_5fprecondition_28',['jacobi_precondition',['../namespaceutil_1_1sp.html#a8c5a8ca79e4555ab1336ac9c64325c01',1,'util::sp']]]
];
