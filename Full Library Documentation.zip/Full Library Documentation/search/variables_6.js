var searchData=
[
  ['size_5fof_5fvalues_149',['size_of_values',['../class_matrix.html#a644f5f067486f44bc73e4b558d7c1aae',1,'Matrix']]]
];
