var searchData=
[
  ['row_5fposition_147',['row_position',['../class_c_s_r_matrix.html#a957d27a1f93fdf5776ea44a9316265f1',1,'CSRMatrix']]],
  ['rows_148',['rows',['../class_matrix.html#acd67456c163fd2259c8aef072c9177fa',1,'Matrix']]]
];
