var searchData=
[
  ['vecvecsub_135',['vecvecsub',['../namespaceutil.html#a2c86f345089f3ce3bb7b735e03dfd3c1',1,'util']]]
];
