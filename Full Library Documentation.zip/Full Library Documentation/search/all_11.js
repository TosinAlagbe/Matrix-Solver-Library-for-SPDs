var searchData=
[
  ['values_69',['values',['../class_matrix.html#a089a93af414a79e3bd6dec66eed145b1',1,'Matrix']]],
  ['vecvecsub_70',['vecvecsub',['../namespaceutil.html#a2c86f345089f3ce3bb7b735e03dfd3c1',1,'util']]]
];
