var searchData=
[
  ['preallocated_146',['preallocated',['../class_matrix.html#a36366d8592b34437a738204ee8aea417',1,'Matrix']]]
];
