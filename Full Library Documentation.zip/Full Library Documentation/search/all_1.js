var searchData=
[
  ['back_5fsub_2',['back_sub',['../namespaceutil_1_1dense.html#aaa6a5ff6175fc806f70cc342d4651022',1,'util::dense']]],
  ['back_5fsub_5fl_3',['back_sub_l',['../namespaceutil_1_1dense.html#a74dbff24b98ab0f19d97bbcd0a0d696e',1,'util::dense']]],
  ['band_5fback_5fsub_5fl_4',['band_back_sub_l',['../namespaceutil_1_1band.html#a9000ae39b20a3a03fc8c00aa78e53795',1,'util::band']]],
  ['band_5fbackward_5fsub_5',['band_backward_sub',['../namespaceutil_1_1band.html#ad5118f202420790a272f756a7a8a0401',1,'util::band::band_backward_sub(Matrix&lt; T &gt; &amp;upper, std::vector&lt; T &gt; &amp;b_rhs, int l_bw)'],['../namespaceutil_1_1band.html#aba28afb11f735b18a21ee7dd3213582a',1,'util::band::band_backward_sub(BandedMat&lt; T &gt; &amp;upper, std::vector&lt; T &gt; &amp;b_rhs)']]],
  ['band_5fcholesky_6',['band_cholesky',['../namespaceutil_1_1band.html#a46bc1f8c0f63ca08598feca24abb6a4c',1,'util::band']]],
  ['band_5fforward_5fsub_7',['band_forward_sub',['../namespaceutil_1_1band.html#aa5437cf62a71f7a1b3fc9794aa996720',1,'util::band::band_forward_sub(Matrix&lt; T &gt; &amp;lower, std::vector&lt; T &gt; &amp;b_rhs, int u_bw)'],['../namespaceutil_1_1band.html#a9fc2a27e470025fc58265bdc2d707201',1,'util::band::band_forward_sub(BandedMat&lt; T &gt; &amp;lower, std::vector&lt; T &gt; &amp;b_rhs)']]],
  ['band_5fgaussian_8',['band_gaussian',['../namespaceutil_1_1band.html#aa68dd9f5eb254ccfe90d1a76cf327028',1,'util::band::band_gaussian(Matrix&lt; T &gt; *mat, int l_bw, int u_bw)'],['../namespaceutil_1_1band.html#aa9bf09d4b60e50379613a7e186dbf7b5',1,'util::band::band_gaussian(BandedMat&lt; T &gt; *mat)']]],
  ['band_5fmat_9',['band_mat',['../class_banded_mat.html#adfb5c8b9a29cfd34272858c84e1fd3d0',1,'BandedMat']]],
  ['bandedmat_10',['BandedMat',['../class_banded_mat.html',1,'BandedMat&lt; T &gt;'],['../class_banded_mat.html#a22a532e982a3d531d7e1ad17a4c7296a',1,'BandedMat::BandedMat(int lwr_bw, int upr_bw, Matrix&lt; T &gt; &amp;mat)'],['../class_banded_mat.html#a0f467645a64b135cd640f53228458fb4',1,'BandedMat::BandedMat(int rows, int cols, int lwr_bw, int upr_bw)'],['../class_banded_mat.html#aa48aa2064f4b541ddc648eaa48ea801c',1,'BandedMat::BandedMat(Matrix&lt; T &gt; &amp;banded, int lwr_bw, int upr_bw)'],['../class_banded_mat.html#a584c5c2b2ec6c682e9fa6ab0452828b9',1,'BandedMat::BandedMat(int rows, int cols, T *values_ptr, int lwr_bw, int upr_bw)']]]
];
