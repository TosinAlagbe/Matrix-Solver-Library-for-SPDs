var searchData=
[
  ['band_82',['band',['../namespaceutil_1_1band.html',1,'util']]],
  ['dense_83',['dense',['../namespaceutil_1_1dense.html',1,'util']]],
  ['sp_84',['sp',['../namespaceutil_1_1sp.html',1,'util']]],
  ['util_85',['util',['../namespaceutil.html',1,'']]]
];
